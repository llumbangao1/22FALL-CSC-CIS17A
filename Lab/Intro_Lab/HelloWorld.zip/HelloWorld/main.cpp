/* 
 * File:   main.cpp
 * Author: Liona Lumban-Gaol
 * Created on August 29, 2022, 9:45 PM
 * Purpose:  
 */

//System Level Libraries
#include <iostream>   //I/O Library
#include <cmath>      //Math Library
using namespace std;  //Library Scope

//User Libraries

//Global Constants
//Science and Math, Conversions, Higher Dimensions const to follow

//Function Prototypes

//Execution Starts Here
int main(int argc, char** argv){
    //Set Random Number Seed Here
    
    //Declare Variables - Known and Unknown, units, range, description
    
    //Initialize Variables
    
    //Map inputs to outputs -> i.e. process the inputs
    
    //Display the outputs
    cout
            << "Hello "
            << "World"
            << endl;
    
    //Another way to do the same thing!
    
    cout << "Hello World" << endl;
    
    //Another way to do the same thing!
    
    cout << "Hello " << "World" << endl;
    
    //Another way to do the same thing!
    
    cout << "Hello ";
    cout << "World";
    cout << endl;
    
    //Another way to do the same thing!
    
    printf("Hello World");
    
    //Clean up - File closing, memory deallocation, etc....

    //Exit Stage Right!
    return 0;
}

//Function Implementations